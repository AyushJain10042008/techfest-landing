# Techfest 30 — Concept Landing Page

A concept landing page for **Techfest**, IIT Bombay's annual science & technology festival (Asia's largest, running since 1998). No 3D assets — just colour-blocked editorial design, kinetic variable-font type and 2D canvas motion.

> Unofficial, student-built design concept. Not affiliated with or endorsed by Techfest or IIT Bombay. No logos or brand assets from the official site are used; the "Tf" mark is original. All registration links point to [techfest.org](https://techfest.org).

## The idea — "The Periodic Table of Techfest"
Techfest is a festival of science, so the page is built like a lab notebook. Everything the festival offers becomes one of **eight elements** (Cp Competitions, Lc Lectures, Ex Exhibitions, Ws Workshops, Th Technoholix, Oz Ozone, Sm Summits, Si Social Initiatives). The 30th edition becomes "element number 30". Five bold colour blocks (paper → electric blue → paper → ink → lime → orange) turn scrolling into a reaction.

## Interactions
- **Kinetic hero type** — letters swell in weight (variable font) as the cursor nears; idle wave when untouched
- **Atom field** — 2D canvas particles bond to each other and to the cursor; click to split an atom
- **Odometer countdown** to 16 Dec 2026
- **Interactive periodic table** — hover/tap an element to inspect it (auto-cycles until you interact)
- **Prize ledger** — bars grow on scroll; rows invert on hover
- **Scroll-drawn timeline** from 1998 to 2026
- Magnetic buttons, tilt cards, inverting spotlight cursor, marquee, count-up stats
- Responsive, keyboard accessible, `prefers-reduced-motion` supported

## Tech
Plain HTML, CSS and vanilla JS — no build step, no dependencies. Fonts: Bricolage Grotesque, Instrument Serif, DM Mono (Google Fonts).

## Run locally
```bash
python3 -m http.server 8000   # or: npx serve .
```
Open http://localhost:8000

## Deploy to GitHub Pages
Push to `main`, then **Settings → Pages → Source: GitHub Actions**. The included workflow publishes the site.

## Content & sources
Facts come from public sources (Wikipedia's Techfest article, IIT Bombay Alumni Association coverage, and press/community write-ups of the 2026–27 edition). Items to verify against techfest.org before any real use:
- Festival dates (**16–18 Dec 2026**) were reported by a third-party guide, not a formal announcement
- Prize pools, accommodation prices and CES 2027 details were as listed in Sept 2026
- 2025 figures (1.8 lakh footfall, 35,000+ participants, 300+ events, 20+ countries)

Content lives in `js/main.js` (`ELEMENTS`, `PRIZES`, `MILESTONES`) and `index.html`.

## Structure
```
index.html       markup
css/style.css    styles
js/main.js       interactions + content data
```

## License
MIT © Ayush Jain (code only; Techfest is a trademark of its respective owners)
