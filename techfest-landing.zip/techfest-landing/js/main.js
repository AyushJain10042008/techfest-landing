/* ==========================================================
   Techfest 30 — concept landing page · interactions (vanilla JS)
   ========================================================== */
(() => {
  'use strict';
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
  const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const fine = matchMedia('(pointer: fine)').matches;
  const root = document.documentElement;
  const COL = { ink: '#0c0c16', blue: '#2a38ff', orange: '#ff5b1f', lime: '#cfff3d' };

  /* ---------------- content ---------------- */
  const ELEMENTS = [
    { s: 'Cp', n: 'Competitions', c: '#cfff3d', t: 'The core reaction. Coding, robotics, aerospace, gaming and ideation challenges that pull in tens of thousands of students from across the country.',
      l: ['Robowars — the flagship robot combat arena', 'AI, quant and hackathon challenges', 'Free registration, open to every college'], v: '₹1 Cr+', vl: 'prize pool this season' },
    { s: 'Lc', n: 'Lecture Series', c: '#ff8ad8', t: 'Big ideas from the people who made them. Global dignitaries, scientists and founders take the stage on campus.',
      l: ['Past speakers include A.P.J. Abdul Kalam, the 14th Dalai Lama and Amartya Sen', 'Nobel laureates to Gaganyaan astronauts', 'Open to all festival visitors'], v: '1998', vl: 'speaking since' },
    { s: 'Ex', n: 'International Exhibitions', c: '#6ee7ff', t: 'The future, parked on a campus. Robotics, AI, aerospace and defence showcases from over thirty countries.',
      l: ['Humanoid robots, jet suits and race cars on display', 'Past highlights: Unitree G1, Sophia, Formula E Gen 2', 'Hands-on demos, not just glass cases'], v: '30+', vl: 'countries exhibiting' },
    { s: 'Ws', n: 'Workshops', c: '#ffd23d', t: 'Learn it by building it. Hands-on, industry-relevant sessions across 25+ domains, taught by practitioners.',
      l: ['AI, robotics, cybersecurity, web development', 'Small cohorts, real hardware and code', 'Flagship series announced each season'], v: '25+', vl: 'domains covered' },
    { s: 'Th', n: 'Technoholix', c: '#b9a6ff', t: 'The techno-cultural night. Where engineering turns into spectacle — lasers, drones and a very large speaker system.',
      l: ['Laser shows and EDM', 'Drone displays across the campus sky', 'The festival after-hours'], v: '3', vl: 'nights of spectacle' },
    { s: 'Oz', n: 'Ozone', c: '#5dffb0', t: 'The amusement zone. Games, gadgets and attractions for anyone who came to play instead of present.',
      l: ['Gadget demos and interactive games', 'Family-friendly and open to all', 'The place to take a break between lectures'], v: '∞', vl: 'high scores' },
    { s: 'Sm', n: 'Summits & Conclaves', c: '#ff7a7a', t: 'Where industry meets campus. Focused summits on AI, fintech, blockchain and media, plus education guidance for students.',
      l: ['Industry–academia collaboration through Tech Connect', 'EduFair and Ed-Conclave for higher studies', 'Panels with leaders from across sectors'], v: '4+', vl: 'sector summits' },
    { s: 'Si', n: 'Social Initiatives', c: '#ff9b4a', t: 'Techfest runs all year, not only in December. Student-led campaigns that put science and technology to work for communities.',
      l: ['SSAP — solar lamps for off-grid homes', 'SHE (menstrual health) and SPEAK (mental health)', 'Saksham — disability inclusion'], v: '365', vl: 'days of impact' }
  ];

  const PRIZES = [
    { n: 'Pushpak Grand Challenge', g: 'Grand challenge', v: 25.5, pre: 'Up to ', c: COL.orange },
    { n: 'AI for Technology Readiness', g: 'AI challenge', v: 4.8, c: COL.blue },
    { n: 'The Quantitative Code Conflux', g: 'Quant × code', v: 3.8, c: COL.blue },
    { n: 'National Probability Challenge', g: 'Maths & probability', v: 3.8, c: COL.blue },
    { n: 'Perceptron Hackathon', g: 'Hackathon', v: 2, c: COL.blue },
    { n: 'EV Infra & Green Mobility AI Challenge', g: 'Mobility', v: 2, c: COL.blue },
    { n: 'OLL Robotics Championship', g: 'Robotics', v: 1.5, c: COL.blue },
    { n: 'Namma Space', g: 'Space', v: 1.5, c: COL.blue },
    { n: 'Meshmerize', g: 'Robotics', v: 1, c: COL.blue }
  ];

  const MILESTONES = [
    { y: '1998', t: 'The first reaction', p: 'Techfest begins at IIT Bombay — built to give Indian students a platform to develop and showcase their projects.' },
    { y: 'Since', t: 'A very good guest list', p: 'Over the years the stage has hosted A.P.J. Abdul Kalam, the 14th Dalai Lama, Amartya Sen and Serge Haroche.' },
    { y: '2024', t: 'Humanoids on campus', p: 'The 28th edition brought the Unitree G1 humanoid, drone and laser shows, and International Robowars finals.' },
    { y: '2025', t: 'The 29th edition', p: '22–24 December. About 1.8 lakh visitors, 35,000+ competition participants and a Robowars crowd of over 20,000.' },
    { y: '2026', t: 'Element number 30', p: '16–18 December. Free registration, a ₹1 crore+ prize pool and workshops across 25+ domains.', now: true }
  ];

  /* ---------------- boot ---------------- */
  const title = $('#title');
  let ci = 0;
  $$('[data-split]', title).forEach(row => {
    const txt = row.textContent; row.textContent = '';
    [...txt].forEach(ch => {
      const s = document.createElement('span');
      s.className = 'ch'; s.textContent = ch; s.style.setProperty('--i', ci++);
      row.appendChild(s);
    });
  });
  const go = () => document.body.classList.add('go');
  (document.fonts && document.fonts.ready ? Promise.race([document.fonts.ready, new Promise(r => setTimeout(r, 900))]) : Promise.resolve()).then(go);
  setTimeout(go, 1200);

  /* ---------------- nav ---------------- */
  const nav = $('#nav'), links = $('#links'), burger = $('#burger');
  const onScroll = () => nav.classList.toggle('stuck', scrollY > 30);
  addEventListener('scroll', onScroll, { passive: true }); onScroll();
  burger.addEventListener('click', () => {
    const o = links.classList.toggle('open'); burger.setAttribute('aria-expanded', o);
  });
  $$('a', links).forEach(a => a.addEventListener('click', () => { links.classList.remove('open'); burger.setAttribute('aria-expanded', 'false'); }));

  /* ---------------- pointer: spotlight + magnetic ---------------- */
  const spot = $('.spot');
  const ptr = { x: innerWidth / 2, y: innerHeight / 2, t: 0, sx: innerWidth / 2, sy: innerHeight / 2 };
  if (fine) root.classList.add('has-spot');
  addEventListener('pointermove', e => {
    ptr.x = e.clientX; ptr.y = e.clientY; ptr.t = performance.now();
    if (fine) spot.classList.toggle('big', !!e.target.closest('a,button,.el'));
  }, { passive: true });
  if (fine && !reduce) {
    $$('.mag').forEach(el => {
      el.addEventListener('pointermove', e => {
        const r = el.getBoundingClientRect();
        el.style.transform = `translate(${(e.clientX - r.left - r.width / 2) * 0.22}px,${(e.clientY - r.top - r.height / 2) * 0.28}px)`;
      });
      el.addEventListener('pointerleave', () => { el.style.transform = ''; });
    });
    $$('.tilt').forEach(el => {
      el.addEventListener('pointermove', e => {
        const r = el.getBoundingClientRect(), x = (e.clientX - r.left) / r.width - 0.5, y = (e.clientY - r.top) / r.height - 0.5;
        el.style.setProperty('--ry', (x * 9).toFixed(2) + 'deg'); el.style.setProperty('--rx', (-y * 9).toFixed(2) + 'deg');
      });
      el.addEventListener('pointerleave', () => { el.style.setProperty('--rx', '0deg'); el.style.setProperty('--ry', '0deg'); });
    });
  }

  /* ---------------- hero: variable-font title ---------------- */
  const chars = $$('.ch', title);
  const hero = $('.hero');
  let heroVisible = true;
  new IntersectionObserver(es => { heroVisible = es[0].isIntersecting; }, { threshold: 0 }).observe(hero);

  /* ---------------- hero: atoms canvas ---------------- */
  const cv = $('#atoms'), ctx = cv.getContext('2d');
  let W = 0, H = 0, dpr = 1, atoms = [], sparks = [];
  const palette = [COL.ink, COL.ink, COL.blue, COL.orange];
  function sizeCanvas() {
    const r = hero.getBoundingClientRect();
    dpr = Math.min(devicePixelRatio || 1, 2);
    W = r.width; H = r.height;
    cv.width = W * dpr; cv.height = H * dpr;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    const n = clamp(Math.round((W * H) / 15000), 26, 86);
    atoms = Array.from({ length: n }, () => ({
      x: Math.random() * W, y: Math.random() * H,
      vx: (Math.random() - 0.5) * 0.35, vy: (Math.random() - 0.5) * 0.35,
      r: 2 + Math.random() * 3.2, c: palette[(Math.random() * palette.length) | 0]
    }));
  }
  sizeCanvas();
  let rz; addEventListener('resize', () => { clearTimeout(rz); rz = setTimeout(sizeCanvas, 150); });
  hero.addEventListener('click', e => {
    if (e.target.closest('a,button')) return;
    const r = hero.getBoundingClientRect(), x = e.clientX - r.left, y = e.clientY - r.top;
    for (let i = 0; i < 14; i++) {
      const a = (i / 14) * Math.PI * 2 + Math.random() * 0.4, sp = 1.5 + Math.random() * 3;
      sparks.push({ x, y, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp, life: 1, c: palette[(Math.random() * palette.length) | 0] });
    }
    atoms.forEach(a => { const dx = a.x - x, dy = a.y - y, d = Math.hypot(dx, dy) || 1; if (d < 260) { a.vx += (dx / d) * (260 - d) * 0.02; a.vy += (dy / d) * (260 - d) * 0.02; } });
  });

  /* ---------------- odometer ---------------- */
  const TARGET = new Date('2026-12-16T00:00:00+05:30').getTime();
  const cols = {};
  $$('.od-grp').forEach(g => {
    cols[g.dataset.unit] = $$('.od', g).map(od => {
      const col = document.createElement('span'); col.className = 'od-col';
      for (let i = 0; i < 10; i++) { const s = document.createElement('span'); s.textContent = i; col.appendChild(s); }
      od.appendChild(col); return col;
    });
  });
  function setOd(unit, val) {
    const [a, b] = cols[unit]; val = clamp(val, 0, 99);
    a.style.transform = `translateY(${-Math.floor(val / 10) * 1.1}em)`;
    b.style.transform = `translateY(${-(val % 10) * 1.1}em)`;
  }
  function tickClock() {
    const s = Math.max(0, (TARGET - Date.now()) / 1000);
    setOd('d', Math.floor(s / 86400)); setOd('h', Math.floor(s % 86400 / 3600));
    setOd('m', Math.floor(s % 3600 / 60)); setOd('s', Math.floor(s % 60));
  }
  tickClock(); setInterval(tickClock, 1000);

  /* ---------------- main animation loop ---------------- */
  let t0 = performance.now();
  function frame(now) {
    requestAnimationFrame(frame);
    if (document.hidden || !heroVisible) return;
    const t = (now - t0) / 1000;

    // title weight: proximity to cursor, idle wave otherwise
    if (!reduce && document.body.classList.contains('go')) {
      const active = now - ptr.t < 2200;
      chars.forEach((c, i) => {
        let w;
        if (active) {
          const r = c.getBoundingClientRect(), d = Math.hypot(ptr.x - (r.left + r.width / 2), ptr.y - (r.top + r.height / 2));
          w = 380 + 420 * Math.max(0, 1 - d / 320);
        } else w = 560 + 240 * Math.sin(t * 1.5 + i * 0.75);
        const cur = +c._w || 500; const nw = cur + (w - cur) * 0.14; c._w = nw;
        c.style.fontVariationSettings = `'wght' ${nw.toFixed(0)},'wdth' ${(100 - (nw - 380) / 420 * 12).toFixed(0)}`;
      });
    }

    // atoms
    const r = hero.getBoundingClientRect();
    const mx = ptr.x - r.left, my = ptr.y - r.top, hasM = fine && now - ptr.t < 4000;
    ctx.clearRect(0, 0, W, H);
    for (const a of atoms) {
      a.x += a.vx; a.y += a.vy; a.vx *= 0.995; a.vy *= 0.995;
      if (Math.abs(a.vx) < 0.12) a.vx += (Math.random() - 0.5) * 0.02;
      if (Math.abs(a.vy) < 0.12) a.vy += (Math.random() - 0.5) * 0.02;
      if (a.x < 0 || a.x > W) a.vx *= -1; if (a.y < 0 || a.y > H) a.vy *= -1;
      if (hasM) { const dx = mx - a.x, dy = my - a.y, d = Math.hypot(dx, dy); if (d < 170 && d > 1) { a.vx += (dx / d) * 0.012; a.vy += (dy / d) * 0.012; } }
    }
    ctx.lineWidth = 1;
    for (let i = 0; i < atoms.length; i++) {
      const a = atoms[i];
      for (let j = i + 1; j < atoms.length; j++) {
        const b = atoms[j], d = Math.hypot(a.x - b.x, a.y - b.y);
        if (d < 120) { ctx.strokeStyle = `rgba(12,12,22,${(1 - d / 120) * 0.3})`; ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke(); }
      }
      if (hasM) {
        const d = Math.hypot(a.x - mx, a.y - my);
        if (d < 180) { ctx.strokeStyle = `rgba(255,91,31,${(1 - d / 180) * 0.85})`; ctx.lineWidth = 1.6; ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(mx, my); ctx.stroke(); ctx.lineWidth = 1; }
      }
    }
    for (const a of atoms) { ctx.fillStyle = a.c; ctx.beginPath(); ctx.arc(a.x, a.y, a.r, 0, 6.2832); ctx.fill(); }
    sparks = sparks.filter(s => s.life > 0);
    for (const s of sparks) {
      s.x += s.vx; s.y += s.vy; s.vx *= 0.95; s.vy *= 0.95; s.life -= 0.02;
      ctx.globalAlpha = Math.max(0, s.life); ctx.fillStyle = s.c; ctx.beginPath(); ctx.arc(s.x, s.y, 3 * s.life + 1, 0, 6.2832); ctx.fill();
    }
    ctx.globalAlpha = 1;
  }
  if (!reduce) requestAnimationFrame(frame);
  else { // static, single draw
    heroVisible = true; frame(performance.now());
  }

  // spotlight follows with easing (separate light loop)
  (function spotLoop() {
    ptr.sx += (ptr.x - ptr.sx) * 0.2; ptr.sy += (ptr.y - ptr.sy) * 0.2;
    if (fine) spot.style.transform = `translate(${ptr.sx}px,${ptr.sy}px)`;
    requestAnimationFrame(spotLoop);
  })();

  /* ---------------- periodic table ---------------- */
  const grid = $('#ptGrid'), detail = $('#ptDetail'), bar = $('#pdBar');
  let sel = 0, auto = true, autoT = 0;
  ELEMENTS.forEach((e, i) => {
    const b = document.createElement('button');
    b.className = 'el'; b.style.setProperty('--c', e.c); b.setAttribute('role', 'tab'); b.setAttribute('aria-label', e.n);
    b.innerHTML = `<span class="n">${String(i + 1).padStart(2, '0')}</span><span class="s">${e.s}</span><span class="m">${e.n.replace(' & ', ' &amp; ')}</span>`;
    b.addEventListener('click', () => { auto = false; select(i); });
    b.addEventListener('pointerenter', () => { if (fine) { auto = false; select(i); } });
    grid.appendChild(b);
  });
  function select(i) {
    sel = i; const e = ELEMENTS[i];
    $$('.el', grid).forEach((b, k) => { b.classList.toggle('on', k === i); b.setAttribute('aria-selected', k === i); });
    detail.style.setProperty('--c', e.c);
    $('#pdSym').textContent = e.s; $('#pdNum').textContent = 'No. ' + String(i + 1).padStart(2, '0') + ' / 08';
    $('#pdName').textContent = e.n; $('#pdText').textContent = e.t;
    const ul = $('#pdList'); ul.innerHTML = ''; e.l.forEach(x => { const li = document.createElement('li'); li.textContent = x; ul.appendChild(li); });
    $('#pdStat').textContent = e.v; $('#pdStatL').textContent = e.vl;
    detail.classList.remove('swap'); void detail.offsetWidth; detail.classList.add('swap');
    clearTimeout(autoT); bar.style.transition = 'none'; bar.style.width = '0';
    if (auto && !reduce) {
      void bar.offsetWidth; bar.style.transition = 'width 5s linear'; bar.style.width = '100%';
      autoT = setTimeout(() => { if (auto) select((sel + 1) % ELEMENTS.length); }, 5000);
    }
  }
  select(0);

  /* ---------------- prize ledger ---------------- */
  const ledger = $('#ledger'), maxV = Math.max(...PRIZES.map(p => p.v));
  PRIZES.forEach((p, i) => {
    const li = document.createElement('li');
    li.style.setProperty('--c', p.c);
    li.innerHTML = `<span class="l-n">${String(i + 1).padStart(2, '0')}</span>
      <span class="l-t"></span>
      <span class="l-bar"><i data-w="${(Math.sqrt(p.v / maxV) * 100).toFixed(1)}"></i></span>
      <span class="l-v">${p.pre ? `<small>${p.pre.trim().toUpperCase()}</small>` : ''}₹${p.v} L<small>LAKH</small></span>`;
    $('.l-t', li).innerHTML = '';
    const t = $('.l-t', li); t.textContent = p.n; const sm = document.createElement('small'); sm.textContent = p.g; t.appendChild(sm);
    ledger.appendChild(li);
  });

  /* ---------------- timeline ---------------- */
  const tlList = $('#tlList'), tlFill = $('#tlFill'), tl = $('#tl');
  MILESTONES.forEach(m => {
    const li = document.createElement('li'); if (m.now) li.className = 'now';
    li.innerHTML = '<div class="y"></div><h3></h3><p></p>';
    $('.y', li).textContent = m.y; $('h3', li).textContent = m.t; $('p', li).textContent = m.p;
    tlList.appendChild(li);
  });
  function tlProgress() {
    const r = tl.getBoundingClientRect();
    const p = clamp((innerHeight * 0.6 - r.top) / r.height, 0, 1);
    tlFill.style.height = (p * 100).toFixed(1) + '%';
  }
  addEventListener('scroll', tlProgress, { passive: true }); addEventListener('resize', tlProgress); tlProgress();

  /* ---------------- reveal + counters ---------------- */
  function countUp(el) {
    const end = parseFloat(el.dataset.count), dec = +(el.dataset.dec || 0), pre = el.dataset.pre || '', suf = el.dataset.suf || '';
    const fmt = v => pre + (dec ? v.toFixed(dec) : Math.round(v).toLocaleString('en-IN')) + suf;
    if (reduce) { el.textContent = fmt(end); return; }
    const t0 = performance.now();
    (function step(now) {
      const p = clamp((now - t0) / 1500, 0, 1), e = 1 - Math.pow(1 - p, 4);
      el.textContent = fmt(end * e);
      if (p < 1) requestAnimationFrame(step);
    })(t0);
  }
  const io = new IntersectionObserver(es => es.forEach(e => {
    if (!e.isIntersecting) return;
    e.target.classList.add('in'); io.unobserve(e.target);
    $$('[data-count]', e.target).forEach(countUp);
  }), { threshold: 0.15 });
  $$('.rv').forEach(el => io.observe(el));

  const io2 = new IntersectionObserver(es => es.forEach(e => {
    if (!e.isIntersecting) return;
    const i = $('i[data-w]', e.target); if (i) { i.style.transitionDelay = (ledger.children.length ? [...ledger.children].indexOf(e.target) * 70 : 0) + 'ms'; i.style.width = i.dataset.w + '%'; }
    io2.unobserve(e.target);
  }), { threshold: 0.4 });
  [...ledger.children].forEach(li => io2.observe(li));

  const io3 = new IntersectionObserver(es => es.forEach(e => { e.target.classList.toggle('in', e.isIntersecting || e.boundingClientRect.top < 0); }), { threshold: 0.5, rootMargin: '0px 0px -10% 0px' });
  [...tlList.children].forEach(li => io3.observe(li));
})();
